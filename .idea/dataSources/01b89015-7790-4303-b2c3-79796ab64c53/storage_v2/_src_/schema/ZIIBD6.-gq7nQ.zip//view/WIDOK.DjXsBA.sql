CREATE VIEW WIDOK AS
  SELECT d.department_name,  MAX(e.salary) as "Maksymalne wynagrodzenie", AVG(e.salary) as "Średnie wynagrodzenie", COUNT(e.department_id) as "Liczba pracowników"  FROM employees e INNER JOIN departments d on e.department_id = d.department_id GROUP BY d.department_name
/

